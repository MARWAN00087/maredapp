
🔧 تعليمات التعديل على تطبيق MaredApp:

1. تغيير اسم التطبيق:
   - افتح ملف android/app/src/main/AndroidManifest.xml
   - غيّر android:label="MaredApp" إلى الاسم الذي تريده

2. تغيير الأيقونة:
   - استبدل الصور داخل مجلد assets/icons أو استخدم flutter_launcher_icons

3. تغيير الألوان:
   - افتح ملف lib/theme.dart (إن وُجد)، وعدّل الأكواد اللونية

4. تعديل الأقسام:
   - افتح ملف lib/pages/home.dart وأضف أو عدّل الأقسام

5. تسجيل الدخول بالجوال:
   - مرتبط بـ Firebase Auth، تأكد من إدخال ملف google-services.json وربط المشروع على Firebase

6. إصدار APK جديد:
   - من الطرفية اكتب: flutter build apk --release
