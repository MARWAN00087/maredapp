// main.dart for MaredApp
void main() => runApp(MyApp());