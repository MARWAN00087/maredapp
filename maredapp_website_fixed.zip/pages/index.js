export default function Home() {
  return <h1>مرحبًا بك في MaredApp</h1>
}
