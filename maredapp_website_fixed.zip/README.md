# MaredApp

مشروع موقع إعلانات بسيط باستخدام Next.js